import React, { useState, useEffect } from 'react';
import api from '../../../api/axiosConfig';
import { toast } from 'react-toastify';

const AdminManager = () => {
  const [admins, setAdmins] = useState([]);
  const [formData, setFormData] = useState({
    userId: '',
    fullName: '',
    username: '',
    password: '',
    department: '',
    email: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      const response = await api.get('/admin/admins');
      setAdmins(response.data.data);
    } catch (err) {
      toast.error('Failed to load admins');
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/admin/admins', formData);
      toast.success('Admin created successfully');
      setFormData({ userId: '', fullName: '', username: '', password: '', department: '', email: '' });
      fetchAdmins();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create admin');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (userId) => {
    if (!window.confirm(`Delete admin ${userId}?`)) return;
    try {
      await api.delete(`/admin/admins/${userId}`);
      toast.success('Admin deleted');
      fetchAdmins();
    } catch (err) {
      toast.error('Failed to delete admin');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-primary">Admin Management</h2>
      <div className="card p-6 mb-6">
        <h3 className="text-xl font-semibold mb-4">Add New Admin</h3>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-md">
          <input type="text" name="userId" value={formData.userId} onChange={handleChange} placeholder="Admin ID (e.g. A001)" className="form-input" required />
          <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} placeholder="Full Name" className="form-input" required />
          <input type="text" name="username" value={formData.username} onChange={handleChange} placeholder="Username" className="form-input" required />
          <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" className="form-input" required />
          <input type="text" name="department" value={formData.department} onChange={handleChange} placeholder="Department" className="form-input" required />
          <input 
            type="password" 
            name="password" 
            value={formData.password} 
            onChange={handleChange} 
            placeholder="Password (Max 8, 1 Upper, 1 Lower, 1 Num)" 
            className="form-input" 
            pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{1,8}$" 
            title="Max 8 characters, at least 1 uppercase, 1 lowercase, 1 number"
            required 
          />
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Adding...' : 'Add Admin'}
          </button>
        </form>
      </div>

      <div className="card p-6">
        <h3 className="text-xl font-semibold mb-4">Existing Admins</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border-color">
                <th className="p-4 font-semibold text-text-muted">User ID</th>
                <th className="p-4 font-semibold text-text-muted">Name</th>
                <th className="p-4 font-semibold text-text-muted">Username</th>
                <th className="p-4 font-semibold text-text-muted">Department</th>
                <th className="p-4 font-semibold text-text-muted text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {admins.length > 0 ? admins.map(a => (
                <tr key={a.id} className="border-b border-border-color">
                  <td className="p-4">{a.userId}</td>
                  <td className="p-4">{a.fullName}</td>
                  <td className="p-4">{a.username}</td>
                  <td className="p-4">{a.department}</td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleDelete(a.userId)} className="text-warning hover:underline">Delete</button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="5" className="p-4 text-center text-text-muted">No admins found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminManager;
